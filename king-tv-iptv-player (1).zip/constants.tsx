
import React from 'react';
import { Tv, Film, PlaySquare, Settings, RefreshCw, User, LayoutGrid } from 'lucide-react';
import { Channel } from './types';

export const MOCK_CHANNELS: Channel[] = [
  { id: '1', name: 'HBO Latino', category: 'Premium', logo: 'https://picsum.photos/seed/hbo/100/100', url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8' },
  { id: '2', name: 'ESPN Deportes', category: 'Deportes', logo: 'https://picsum.photos/seed/espn/100/100', url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8' },
  { id: '3', name: 'Discovery Channel', category: 'Documentales', logo: 'https://picsum.photos/seed/discovery/100/100', url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8' },
  { id: '4', name: 'CNN En Español', category: 'Noticias', logo: 'https://picsum.photos/seed/cnn/100/100', url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8' },
  { id: '5', name: 'Disney Channel', category: 'Infantil', logo: 'https://picsum.photos/seed/disney/100/100', url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8' },
];

export const DASHBOARD_ITEMS = [
  { id: 'live', label: 'TV EN VIVO', icon: <Tv size={42} />, view: 'LIVE_TV' },
  { id: 'movies', label: 'PELÍCULAS', icon: <Film size={42} />, view: 'MOVIES' },
  { id: 'series', label: 'SERIES', icon: <PlaySquare size={42} />, view: 'SERIES' },
  { id: 'account', label: 'CUENTA', icon: <User size={42} />, view: 'ACCOUNT' },
  { id: 'playlist', label: 'Listas', icon: <LayoutGrid size={24} />, view: 'DASHBOARD' },
  { id: 'settings', label: 'Ajustes', icon: <Settings size={24} />, view: 'SETTINGS' },
  { id: 'reload', label: 'Recargar', icon: <RefreshCw size={24} />, view: 'RELOAD' },
];
