
import React, { useState } from 'react';
import { ViewType, Channel, PortalConfig } from './types';
import Dashboard from './components/Dashboard';
import ChannelList from './components/ChannelList';
import Player from './components/Player';
import Account from './components/Account';
import Settings from './components/Settings';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewType>(ViewType.DASHBOARD);
  const [selectedChannel, setSelectedChannel] = useState<Channel | null>(null);
  const [showNotification, setShowNotification] = useState<string | null>(null);
  const [portalConfig, setPortalConfig] = useState<PortalConfig | null>(() => {
    const saved = localStorage.getItem('kingtv_config');
    return saved ? JSON.parse(saved) : null;
  });

  const handleNavigate = (view: ViewType) => {
    setCurrentView(view);
  };

  const handleSelectChannel = (channel: Channel) => {
    setSelectedChannel(channel);
    setCurrentView(ViewType.PLAYER);
  };

  const handleSaveConfig = (config: PortalConfig) => {
    setPortalConfig(config);
    localStorage.setItem('kingtv_config', JSON.stringify(config));
  };

  const handleReload = () => {
    if (!portalConfig) {
      setShowNotification('⚠️ Configure su cuenta primero');
    } else {
      setShowNotification('🔄 Sincronizando King TV...');
    }
    
    setTimeout(() => {
      setShowNotification(null);
      if (!portalConfig) setCurrentView(ViewType.ACCOUNT);
    }, 2000);
  };

  return (
    <div className="relative w-full h-screen bg-[#050505] overflow-hidden text-white select-none">
      {/* Views */}
      {currentView === ViewType.DASHBOARD && (
        <Dashboard onNavigate={handleNavigate} onReload={handleReload} />
      )}

      {currentView === ViewType.LIVE_TV && (
        <ChannelList onSelect={handleSelectChannel} onBack={() => setCurrentView(ViewType.DASHBOARD)} />
      )}

      {currentView === ViewType.PLAYER && selectedChannel && (
        <Player channel={selectedChannel} onClose={() => setCurrentView(ViewType.LIVE_TV)} />
      )}

      {currentView === ViewType.ACCOUNT && (
        <Account 
          config={portalConfig} 
          onSave={handleSaveConfig} 
          onBack={() => setCurrentView(ViewType.DASHBOARD)} 
        />
      )}

      {currentView === ViewType.SETTINGS && (
        <Settings onBack={() => setCurrentView(ViewType.DASHBOARD)} />
      )}

      {(currentView === ViewType.MOVIES || currentView === ViewType.SERIES) && (
        <div className="flex flex-col items-center justify-center h-full p-20 text-center animate-in fade-in zoom-in duration-500">
           <div className="text-yellow-600 mb-6 text-6xl opacity-50 font-black">CATÁLOGO</div>
           <div className="text-zinc-500 mb-8 max-w-lg">Cargando biblioteca de contenido premium...</div>
           <button 
             onClick={() => setCurrentView(ViewType.DASHBOARD)}
             className="px-10 py-3 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 rounded-xl transition-all font-bold uppercase tracking-widest text-sm"
           >
             Cerrar
           </button>
        </div>
      )}

      {/* Notifications */}
      {showNotification && (
        <div className="fixed top-12 left-1/2 -translate-x-1/2 z-[100] animate-in slide-in-from-top-10 duration-300">
          <div className="bg-zinc-900 border border-yellow-500/30 text-white px-8 py-4 rounded-2xl shadow-2xl font-bold flex items-center gap-4 backdrop-blur-xl">
            {showNotification.includes('🔄') && <div className="w-4 h-4 border-2 border-yellow-500 border-t-transparent rounded-full animate-spin" />}
            <span className="text-sm">{showNotification}</span>
          </div>
        </div>
      )}

      {/* Footer Branding */}
      <div className="fixed bottom-6 w-full text-center text-[10px] text-zinc-800 uppercase tracking-[0.6em] font-black pointer-events-none">
        King TV Premium • High Fidelity Streaming
      </div>
    </div>
  );
};

export default App;
