
import React from 'react';
import { ArrowLeft, Search } from 'lucide-react';
import { MOCK_CHANNELS } from '../constants';
import { Channel } from '../types';

interface ChannelListProps {
  onSelect: (channel: Channel) => void;
  onBack: () => void;
}

const ChannelList: React.FC<ChannelListProps> = ({ onSelect, onBack }) => {
  return (
    <div className="min-h-screen bg-zinc-950 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-12">
          <div className="flex items-center gap-6">
            <button onClick={onBack} className="p-2 hover:bg-zinc-800 rounded-full transition-colors">
              <ArrowLeft size={32} />
            </button>
            <h2 className="text-4xl font-bold">TV en Vivo</h2>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
            <input 
              type="text" 
              placeholder="Buscar canal..." 
              className="bg-zinc-900 border border-zinc-800 rounded-xl py-3 pl-12 pr-4 w-80 focus:outline-none focus:border-yellow-500 transition-colors"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
          {MOCK_CHANNELS.map(channel => (
            <button
              key={channel.id}
              onClick={() => onSelect(channel)}
              className="group flex flex-col bg-zinc-900 border border-zinc-800 p-4 rounded-2xl hover:bg-zinc-800 hover:border-yellow-500 transition-all transform hover:-translate-y-1"
            >
              <div className="aspect-square bg-zinc-800 rounded-xl overflow-hidden mb-4">
                <img src={channel.logo} alt={channel.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
              </div>
              <span className="font-semibold text-lg truncate w-full">{channel.name}</span>
              <span className="text-xs text-zinc-500 uppercase mt-1 tracking-wider">{channel.category}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ChannelList;
