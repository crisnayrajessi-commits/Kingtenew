
import React, { useState } from 'react';
import { ArrowLeft, Save, Globe, User, Lock, CheckCircle } from 'lucide-react';
import { PortalConfig } from '../types';

interface AccountProps {
  config: PortalConfig | null;
  onSave: (config: PortalConfig) => void;
  onBack: () => void;
}

const Account: React.FC<AccountProps> = ({ config, onSave, onBack }) => {
  const [formData, setFormData] = useState<PortalConfig>(config || {
    dns: '',
    username: '',
    password: ''
  });
  const [isSaved, setIsSaved] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  return (
    <div className="min-h-screen bg-black p-10 flex flex-col">
      <div className="flex items-center gap-6 mb-12">
        <button onClick={onBack} className="p-4 hover:bg-zinc-900 rounded-2xl transition-colors">
          <ArrowLeft size={32} />
        </button>
        <h2 className="text-5xl font-black">Mi Cuenta</h2>
      </div>

      <div className="flex-1 flex items-center justify-center">
        <div className="w-full max-w-2xl bg-zinc-900/50 backdrop-blur-2xl p-12 rounded-[3rem] border border-zinc-800 shadow-2xl">
          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="space-y-2">
              <label className="text-sm font-bold text-zinc-500 uppercase tracking-widest ml-2">Host DNS / URL</label>
              <div className="relative">
                <Globe className="absolute left-4 top-1/2 -translate-y-1/2 text-yellow-500" size={24} />
                <input
                  type="text"
                  value={formData.dns}
                  onChange={(e) => setFormData({...formData, dns: e.target.value})}
                  placeholder="http://example.com:8080"
                  className="w-full bg-black/40 border-2 border-zinc-800 rounded-2xl py-5 pl-14 pr-6 text-xl focus:border-yellow-500 focus:outline-none transition-all"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-zinc-500 uppercase tracking-widest ml-2">Usuario</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 text-yellow-500" size={24} />
                  <input
                    type="text"
                    value={formData.username}
                    onChange={(e) => setFormData({...formData, username: e.target.value})}
                    placeholder="Usuario"
                    className="w-full bg-black/40 border-2 border-zinc-800 rounded-2xl py-5 pl-14 pr-6 text-xl focus:border-yellow-500 focus:outline-none transition-all"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-zinc-500 uppercase tracking-widest ml-2">Contraseña</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-yellow-500" size={24} />
                  <input
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({...formData, password: e.target.value})}
                    placeholder="••••••••"
                    className="w-full bg-black/40 border-2 border-zinc-800 rounded-2xl py-5 pl-14 pr-6 text-xl focus:border-yellow-500 focus:outline-none transition-all"
                    required
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-6 bg-gradient-to-r from-yellow-600 to-yellow-700 hover:from-yellow-500 hover:to-yellow-600 text-white rounded-2xl font-black text-2xl shadow-xl shadow-yellow-900/20 transform active:scale-95 transition-all flex items-center justify-center gap-4"
            >
              {isSaved ? <CheckCircle size={28} /> : <Save size={28} />}
              {isSaved ? "¡GUARDADO!" : "GUARDAR CONFIGURACIÓN"}
            </button>
          </form>

          <div className="mt-10 p-6 bg-black/30 rounded-2xl border border-zinc-800/50 flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-zinc-500 text-xs uppercase font-bold tracking-widest">Estado del Dispositivo</span>
              <span className="text-white font-medium">No se requiere activación (King TV Free)</span>
            </div>
            <div className="px-4 py-1 bg-green-500/10 text-green-500 rounded-full text-xs font-bold border border-green-500/20">
              ACTIVO
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Account;
