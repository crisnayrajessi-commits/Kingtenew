
import React, { useEffect, useRef } from 'react';
import { ArrowLeft, Maximize, Settings, Info } from 'lucide-react';
import { Channel } from '../types';

interface PlayerProps {
  channel: Channel;
  onClose: () => void;
}

const Player: React.FC<PlayerProps> = ({ channel, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    // Simple mock video behavior
    if (videoRef.current) {
      videoRef.current.play().catch(e => console.log("Auto-play blocked"));
    }
  }, [channel]);

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col">
      {/* Top Bar */}
      <div className="absolute top-0 left-0 right-0 p-6 flex justify-between items-center bg-gradient-to-b from-black/80 to-transparent opacity-0 hover:opacity-100 transition-opacity duration-300 z-10">
        <button 
          onClick={onClose}
          className="flex items-center gap-3 text-white bg-white/10 px-4 py-2 rounded-lg hover:bg-white/20"
        >
          <ArrowLeft size={24} />
          <span className="font-semibold">{channel.name}</span>
        </button>
        <div className="flex gap-4 text-white">
          <Settings size={24} className="cursor-pointer" />
          <Info size={24} className="cursor-pointer" />
        </div>
      </div>

      {/* Video Content */}
      <div className="flex-1 flex items-center justify-center bg-zinc-900">
        <video 
          ref={videoRef}
          className="max-w-full max-h-full aspect-video shadow-2xl"
          src={channel.url}
          controls={false}
          autoPlay
          muted={false}
        />
        {/* Mock OSD when no video is loading */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
           <div className="p-8 bg-black/60 backdrop-blur rounded-3xl border border-white/10 flex flex-col items-center">
             <div className="text-yellow-500 animate-pulse mb-4">
                <Maximize size={64} />
             </div>
             <p className="text-zinc-400">Reproduciendo {channel.name}</p>
             <p className="text-xs text-zinc-600 mt-2 italic">Mock Player Engine v1.0</p>
           </div>
        </div>
      </div>

      {/* Bottom Controls (Mock) */}
      <div className="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-black/90 to-transparent opacity-0 hover:opacity-100 transition-opacity duration-300">
        <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
          <div className="bg-yellow-500 h-full w-[45%]" />
        </div>
        <div className="mt-4 flex justify-between items-center">
           <div className="flex flex-col">
             <span className="text-white font-bold">{channel.name}</span>
             <span className="text-zinc-400 text-sm">Ahora: Noticieros de la tarde (14:00 - 15:30)</span>
           </div>
           <div className="text-zinc-500 font-mono">LIVE</div>
        </div>
      </div>
    </div>
  );
};

export default Player;
