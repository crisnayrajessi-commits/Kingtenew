
import React, { useState } from 'react';
import { ArrowLeft, Monitor, Shield, Info, Languages, Clock, Database } from 'lucide-react';

interface SettingsProps {
  onBack: () => void;
}

const Settings: React.FC<SettingsProps> = ({ onBack }) => {
  const [lang, setLang] = useState('Español');
  const [timeFormat, setTimeFormat] = useState('24h');

  const settingsOptions = [
    { id: 'general', icon: <Languages size={24} />, title: 'Idioma de Interfaz', value: lang, options: ['Español', 'English', 'Français'], setter: setLang },
    { id: 'time', icon: <Clock size={24} />, title: 'Formato de Hora', value: timeFormat, options: ['12h', '24h'], setter: setTimeFormat },
    { id: 'parental', icon: <Shield size={24} />, title: 'Control Parental', value: 'Desactivado' },
    { id: 'player', icon: <Monitor size={24} />, title: 'Motor de Reproducción', value: 'ExoPlayer (V3)' },
    { id: 'cache', icon: <Database size={24} />, title: 'Limpiar Caché', value: '42.5 MB' },
    { id: 'info', icon: <Info size={24} />, title: 'Acerca de King TV', value: 'Versión 2.5.0 Gold' },
  ];

  return (
    <div className="min-h-screen bg-black p-10 flex flex-col">
      <div className="flex items-center gap-6 mb-12">
        <button onClick={onBack} className="p-4 hover:bg-zinc-900 rounded-2xl transition-colors">
          <ArrowLeft size={32} />
        </button>
        <h2 className="text-5xl font-black">Ajustes</h2>
      </div>

      <div className="max-w-5xl mx-auto w-full grid grid-cols-1 md:grid-cols-2 gap-4">
        {settingsOptions.map((opt) => (
          <div 
            key={opt.id}
            className="group bg-zinc-900/40 p-8 rounded-[2rem] border border-zinc-800 hover:border-yellow-500/30 transition-all flex items-center justify-between cursor-pointer"
            onClick={() => {
              if (opt.setter && opt.options) {
                const nextIdx = (opt.options.indexOf(opt.value) + 1) % opt.options.length;
                opt.setter(opt.options[nextIdx]);
              }
            }}
          >
            <div className="flex items-center gap-6">
              <div className="w-14 h-14 bg-zinc-800 rounded-2xl flex items-center justify-center text-yellow-500 group-hover:bg-yellow-500 group-hover:text-black transition-all">
                {opt.icon}
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-bold text-white">{opt.title}</span>
                <span className="text-zinc-500 font-medium">{opt.value}</span>
              </div>
            </div>
            {opt.options && (
              <div className="px-4 py-2 bg-black/40 rounded-xl text-xs font-bold text-zinc-400 group-hover:text-yellow-500 transition-colors uppercase tracking-widest">
                Cambiar
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="mt-auto text-center text-zinc-700 font-bold uppercase tracking-[0.5em] text-[10px] pb-10">
        King TV Premium Player • MAC: 00:1A:3F:F1:4D:2B
      </div>
    </div>
  );
};

export default Settings;
