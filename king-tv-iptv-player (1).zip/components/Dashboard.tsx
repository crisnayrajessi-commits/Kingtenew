
import React from 'react';
import { DASHBOARD_ITEMS } from '../constants';
import { ViewType } from '../types';

interface DashboardProps {
  onNavigate: (view: ViewType) => void;
  onReload: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate, onReload }) => {
  const mainGridIds = ['live', 'movies', 'series', 'account'];
  const sideBarIds = ['playlist', 'settings', 'reload'];

  const mainGridItems = DASHBOARD_ITEMS.filter(item => mainGridIds.includes(item.id));
  const sideBarItems = DASHBOARD_ITEMS.filter(item => sideBarIds.includes(item.id));

  const renderButton = (item: typeof DASHBOARD_ITEMS[0], isSmall = false) => (
    <button
      key={item.id}
      onClick={() => {
        if (item.id === 'reload') onReload();
        else onNavigate(item.view as ViewType);
      }}
      className={`
        relative flex flex-col items-center justify-center rounded-[1.5rem] transition-all duration-300
        bg-zinc-900/40 backdrop-blur-md border border-zinc-800/60 hover:border-yellow-500/40 
        group overflow-hidden shadow-lg hover:bg-zinc-800/80
        ${isSmall ? 'flex-1 py-4 px-6' : 'aspect-square py-6'}
      `}
    >
      <div className="absolute top-0 left-0 w-full h-1/2 bg-gradient-to-b from-white/[0.03] to-transparent pointer-events-none" />
      
      <div className={`
        mb-3 transition-transform duration-500 group-hover:scale-110 group-hover:drop-shadow-[0_0_12px_rgba(234,179,8,0.3)]
        ${isSmall ? 'scale-75 text-zinc-500' : 'scale-90 text-yellow-500'}
      `}>
        {item.icon}
      </div>
      
      <span className={`
        font-bold tracking-tight transition-colors text-center px-2 uppercase
        ${isSmall ? 'text-[10px] text-zinc-500 group-hover:text-zinc-300' : 'text-sm text-zinc-400 group-hover:text-white'}
      `}>
        {item.label}
      </span>

      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-[2px] bg-yellow-500 transition-all duration-500 group-hover:w-1/4 rounded-full mb-3 opacity-40" />
    </button>
  );

  return (
    <div className="flex flex-col h-screen bg-[#080808] relative">
      {/* Elegant Ambient Light */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-[400px] bg-yellow-900/10 blur-[120px] rounded-full pointer-events-none" />

      {/* Top Navigation */}
      <div className="flex justify-between items-center px-16 py-10 z-10">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-yellow-600 to-yellow-800 flex items-center justify-center shadow-lg">
            <span className="text-xl font-black text-white">K</span>
          </div>
          <h1 className="text-2xl font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-yellow-500 via-white to-yellow-700">
            KING TV
          </h1>
        </div>
        <div className="flex flex-col items-end">
          <div className="text-2xl font-light text-zinc-200 tabular-nums">
            {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </div>
          <div className="text-[10px] text-yellow-600/60 uppercase font-black tracking-widest">
            Premium Access
          </div>
        </div>
      </div>

      {/* Centered Grid Container */}
      <div className="flex-1 flex items-center justify-center px-6 pb-12 z-10">
        <div className="w-full max-w-4xl grid grid-cols-12 gap-5 items-stretch">
          
          {/* Main 2x2 Grid (Centered more) */}
          <div className="col-span-8 grid grid-cols-2 grid-rows-2 gap-5">
            {mainGridItems.map(item => renderButton(item))}
          </div>

          {/* Right Column (Sidebar) */}
          <div className="col-span-4 flex flex-col gap-5">
            {sideBarItems.map(item => renderButton(item, true))}
          </div>

        </div>
      </div>

      {/* Network Status */}
      <div className="absolute bottom-6 right-10 flex items-center gap-3 bg-zinc-900/50 px-4 py-2 rounded-full border border-zinc-800">
         <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
         <span className="text-[9px] text-zinc-500 font-black uppercase tracking-widest">Network Secure</span>
      </div>
    </div>
  );
};

export default Dashboard;
