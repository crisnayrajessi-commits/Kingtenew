
export interface Channel {
  id: string;
  name: string;
  category: string;
  logo: string;
  url: string;
}

export interface PortalConfig {
  dns: string;
  username: string;
  password: string;
}

export enum ViewType {
  DASHBOARD = 'DASHBOARD',
  LIVE_TV = 'LIVE_TV',
  MOVIES = 'MOVIES',
  SERIES = 'SERIES',
  SETTINGS = 'SETTINGS',
  ACCOUNT = 'ACCOUNT',
  PLAYER = 'PLAYER'
}

export interface AppState {
  view: ViewType;
  config: PortalConfig | null;
  selectedChannel: Channel | null;
}
